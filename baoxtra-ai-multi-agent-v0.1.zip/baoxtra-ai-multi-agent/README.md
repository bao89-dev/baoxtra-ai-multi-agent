# BaoXTra AI Multi-Agent

**Security-first software-development agency** based on the Owner → AI Council → Project Manager (Task DAG) → Developer → Trusted CI → Evidence Store → Independent Verifier → Handoff → QA/DevOps architecture.

> Status: **working offline orchestration and evidence validator**, not a deployed autonomous LLM coding service. No model API keys, GitHub write tokens, production deployments, or live trading are enabled.

## Getting started

Python >=3.10; no third-party runtime dependencies.

```bash
python -m unittest discover -s tests -v
python -m agency.cli plan --input examples/charter.json --output out/plan.json
python -m agency.cli verify --input examples/task.json --output out/verification.json
python -m agency.cli evidence --task examples/task.json --log out/test-output.txt --exit-code 0 --commit 0000000000000000000000000000000000000000 --output out/evidence.json
```

`verify` refuses missing, mismatched, untrusted, incomplete, or failing evidence. A syntactically valid evidence record is **never** treated as GitHub-signed CI provenance: `REVIEW_REQUIRED` means a human must check CI run, SHA, log and source against GitHub before release.

## Components

- `charters/` owner objectives, scope, acceptance criteria.
- `agency/council.py` guardrails and council decision model (non-LLM).
- `agency/dag.py` deterministic DAG planning with cycle validation.
- `agency/core.py` fail-closed evidence and independent review decision.
- `agency/evidence.py` local evidence manifest with log sha256 and SHA checks.
- `agency/cli.py` executable CLI.
- `.github/workflows/ci.yml` unit tests, artifact upload (non-production).
- `schemas/` JSON data contracts; `policies/` restrictions.
- `docs/` rollout plan and integration boundaries.

## Security invariants

- Never run LIVE trades, withdraw funds, send orders or enable broker APIs.
- No direct pushes to protected branch by an agent. PR + required checks + human approval.
- CI PASS is different from independent verification PASS and deployment approval.
- All credentials stored in GitHub Secrets, never inside code or artifacts.
- No auto-merge, auto-deployment or unsupervised external repository writes.

## GitHub setup

1. Upload the **contents** of this folder to `bao89-dev/baoxtra-ai-multi-agent` (not the enclosing folder).
2. Enable Actions and confirm `CI / unit-tests` is green.
3. Settings → Branches / Rulesets: protect `main`, require CI and pull request review.
4. Configure repo-level environment protection for any later integration; keep production secrets absent.
5. Connect target repositories using separately scoped, read-only integration first. Only enable PR creation after tests.

See `docs/ROADMAP.md` and `docs/ARCHITECTURE.md` for what is implemented versus planned.
