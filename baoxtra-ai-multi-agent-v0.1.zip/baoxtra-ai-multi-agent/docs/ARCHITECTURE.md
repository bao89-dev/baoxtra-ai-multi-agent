# Architecture V1

```mermaid
flowchart TD
  OWNER[Owner / Project Charter] --> C[AI Council]
  C --> PM[Project Manager / Task DAG]
  PM --> DEV[Developer / proposed PR]
  DEV --> CI[Trusted CI / Build Test Scan]
  CI --> ES[Evidence Store / logs + hashes]
  ES --> VER[Independent Verifier]
  VER --> G{Evidence accepted?}
  G -->|Fail| DEV
  G -->|Review required| H[Handoff Service]
  H -->|Human approval| NEXT[QA / DevOps]
  VER --> AUDIT[Audit log]
  H --> AUDIT
```

**Implementation status**: Charter validation, DAG, offline manifest generation, fail-closed verification, and unit-test CI are implemented. The diagram represents the **target**: AI Council deliberation, actual coding agents, GitHub PR adapter, authenticated CI provenance, persistent evidence store, identity-separated verifier, audit sink and handoff service are NOT connected.

**Trust boundary:** artifacts and a local SHA256 are necessary but not sufficient. Independent verifier must validate CI job identity, run URL, signed GitHub API provenance, job conclusion and commit SHA from a trusted read-only GitHub integration. No developer-provided `provenance` string can establish trust. Actual automated verification is a future security-reviewed feature.
