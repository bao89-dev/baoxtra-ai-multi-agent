# Release plan

- **V0.1 (included):** offline council charter gating, manager DAG, evidence manifest, fail-closed validator, CLI, unit tests, GitHub CI.
- **V0.2 (not implemented):** GitHub App read-only connector, signed run/SHA fetch, artifact download and independent verification.
- **V0.3 (not implemented):** sandboxed Developer Agent that creates draft PRs, isolated Tester Agent with scoped ephemeral tokens, no push to main.
- **V0.4 (not implemented):** AI Council with separate Tech Lead / Security / PO model roles; approval recording and immutable audit store.
- **V1.0 (not implemented):** Project Manager automation, Handoff service, manual QA and DevOps gates, observability, threat model, penetration testing.

## Required acceptance evidence

1. Repository code and unit tests, with CI run URL and exact SHA.
2. End-to-end test of real agent → PR → CI → independent verifier on throwaway repository.
3. Rejection scenarios: missing charter, DAG cycle, wrong SHA, tampered log, nonzero tests, LIVE, missing evidence.
4. Reviewer independence, least-privilege permissions, rate/cost limits, prompt-injection testing.
5. Explicit owner approval for merges and production actions.
